(function() {
  module.exports = {
    url: 'http://demo.gitlab.com',
    token: 'Wvjy2Krpb7y8xi93owUz'
  };

}).call(this);
